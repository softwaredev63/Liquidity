const priceContracts: {cakeAddress: string, busdAddress: string, lpAddress:string} = {
  cakeAddress: '0x37781b87619722e1765dd4864894931bebD1BB3C',
  busdAddress: '0xe9e7cea3dedca5984780bafc599bd69add087d56',
  lpAddress: '0x0e8532645ad6d45648adfdf798d6d24c4bbf9d94'
}

export default priceContracts